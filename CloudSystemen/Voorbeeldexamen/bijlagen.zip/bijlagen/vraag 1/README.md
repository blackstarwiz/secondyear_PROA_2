Dit is wat de verschillende commando's (in de Dockerfile en terminal) doen en wat hun parameterwaarden betekenen:

ZELF AANVULLEN
